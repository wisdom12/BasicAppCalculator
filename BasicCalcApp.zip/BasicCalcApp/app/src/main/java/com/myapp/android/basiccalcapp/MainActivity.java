package com.myapp.android.basiccalcapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edt1,edt2;
    TextView tvx1;
    Button btn1,btn2,btn3,btn4,btn5;
    int x=0,y=0,res=0;
    int operator=1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        edt1=(EditText) findViewById(R.id.et1);
        edt2=(EditText) findViewById(R.id.et2);
        tvx1=(TextView) findViewById(R.id.tv1);
        btn1=(Button) findViewById(R.id.btn_add);
        btn2=(Button) findViewById(R.id.btn_minus);
        btn3=(Button) findViewById(R.id.btn_mult);
        btn4=(Button) findViewById(R.id.btn_div);
        btn5=(Button) findViewById(R.id.btn_res);





             btn1.setOnClickListener(new View.OnClickListener()

            {
                public void onClick (View v)
                {
                    handleOp(1);
                 }
            }

            );


                btn2.setOnClickListener(new View.OnClickListener()

                                        {
                                            public void onClick(View v)
                                            {
                                                //DO SOMETHING! {RUN SOME FUNCTION ... DO CHECKS... ETC}
                                            handleOp(2);
                                            }
                                        }

                );

                btn3.setOnClickListener(new View.OnClickListener()

                                        {
                                            public void onClick(View v) {
                                                //DO SOMETHING! {RUN SOME FUNCTION ... DO CHECKS... ETC}
                                                handleOp(3);


                                            }
                                        }

                );
                btn4.setOnClickListener(new View.OnClickListener()

                                        {
                                            public void onClick(View v) {
                                                //DO SOMETHING! {RUN SOME FUNCTION ... DO CHECKS... ETC}
                                        handleOp(4);


                                            }
                                        }

                );
                btn5.setOnClickListener(new View.OnClickListener()

                                        {
                                            public void onClick(View v) {
                                                //DO SOMETHING! {RUN SOME FUNCTION ... DO CHECKS... ETC}

                                                tvx1.setText("0");


                                            }
                                        }

                );
                FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
                fab.setOnClickListener(new View.OnClickListener()

                                       {
                                           @Override
                                           public void onClick(View view) {
                                               Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                                                       .setAction("Action", null).show();
                                           }
                                       }

                );
            }

            @Override
            public boolean onCreateOptionsMenu(Menu menu) {
                // Inflate the menu; this adds items to the action bar if it is present.
                getMenuInflater().inflate(R.menu.menu_main, menu);
                return true;
            }

            @Override
            public boolean onOptionsItemSelected(MenuItem item) {
                // Handle action bar item clicks here. The action bar will
                // automatically handle clicks on the Home/Up button, so long
                // as you specify a parent activity in AndroidManifest.xml.
                int id = item.getItemId();

                //noinspection SimplifiableIfStatement
                if (id == R.id.action_settings) {
                    return true;
                }

                return super.onOptionsItemSelected(item);
            }


    public void handleOp(int newop){

        x = Integer.parseInt(edt1.getText().toString());
        y = Integer.parseInt(edt2.getText().toString());
        res=0;
        switch (newop) {
            case 1:
                res = x + y;
                tvx1.setText(String.valueOf(res));
                break;
            case 2:
                res = x - y;
                tvx1.setText(String.valueOf(res));
                break;
            case 3:
                res = x * y;
                tvx1.setText(String.valueOf(res));
                break;
            case 4:
                res = x / y;
                tvx1.setText(String.valueOf(res));
                break;
        }


    }
       }
